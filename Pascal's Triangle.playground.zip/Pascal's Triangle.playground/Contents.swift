import Cocoa

var maxRow = 10
var allNums = [[1]]

for rowNumber in 1...maxRow {
    var row:[Int] = []
    for i in 0...rowNumber {
        if i == 0 || row.count == rowNumber {
            row.append(1)
        } else {
            let newValue = [allNums[rowNumber-1][i], allNums[rowNumber-1][i-1]].reduce(0, +)
            row.append(newValue)
        }
    }
    allNums.append(row)
    print(row)
}
